# Build three Medical Appointment Booking website layouts including the Navigation Bar, the Sign Up form, and the Login form.
